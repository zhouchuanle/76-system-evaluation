#!/bin/bash

if [ $# -ne 4 ]; then
    echo "Usage: $0 [-s A/Y/T/a] [-n number]"
    echo "A/Y/T/a: Android/Yocto/Tbox/all"
    echo "number: Number of executions"
    exit 1
fi

adb -s 127.0.0.1:7666 push stream /data
adb -s 127.0.0.1:7665 push stream /data
adb -s 127.0.0.1:7667 push stream /data

if [ $1 == "-s" ];then
	sys=$2
fi

if [ $3 == "-n" ];then
	num=$4
fi

if [[ $sys == "A" || $sys == "a" ]]; then
    for i in $(seq 1 $num); do
        adb -s 127.0.0.1:7666 shell "/data/stream -v 2 -M 64M -P 4" |tee -a  Android_stream.txt
    done
fi

if [[ $sys == "Y" || $sys == "a" ]]; then
    for i in $(seq 1 $num); do
        adb -s 127.0.0.1:7665 shell "/data/stream -v 2 -M 64M -P 4" |tee -a  Yocto_stream.txt
    done
fi

if [[ $sys == "T" || $sys == "a" ]]; then
    for i in $(seq 1 $num); do
        adb -s 127.0.0.1:7667 shell "/data/stream -v 2 -M 64M -P 2" |tee -a  Tbox_stream.txt
    done
fi

